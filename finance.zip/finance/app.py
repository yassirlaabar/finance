#added feature: users can add cash into their portfolio
import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    #portfolio initialiseren
    portfolio = db.execute("SELECT symbol, SUM(shares) as total_shares FROM portfolio WHERE userid = :userid GROUP BY symbol HAVING total_shares > 0", userid=session["user_id"])

    stocks = []

    # begin waarde stocks
    total_stocks_value = 0

    # Itererern over iedere stock in portfolio
    for stock in portfolio:
        symbol = stock["symbol"]
        shares = stock["total_shares"]
        stock_info = lookup(symbol)
        if stock_info is not None:
            total_value = shares * stock_info["price"]
            stocks.append({"symbol": symbol, "shares": shares, "price": usd(stock_info["price"]), "total": usd(total_value)})
            total_stocks_value += total_value

    # db Query huidige cash balans
    cash = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])[0]["cash"]

    # grand total formule
    grand_total = total_stocks_value + cash

    # Render index.html, 
    return render_template("index.html", stocks=stocks, cash=usd(cash), grand_total=usd(grand_total))
    
@app.route("/add_cash", methods=["GET"])
@login_required
def add_cash():
    return render_template("add_cash.html")

@app.route("/add_cash", methods=["POST"])
@login_required
def process_add_cash():
    # cash retrieve dmv form
    try:
        amount = float(request.form.get("cash_amount")) 
    except ValueError:
        return apology("Invalid amount", 400)
 
    if amount <= 0:
        return apology("Amount must be greater than zero", 400)
    
    # cash balance update
    db.execute("UPDATE users SET cash = cash + :amount WHERE id = :user_id",
               amount=amount, user_id=session["user_id"])
    
    # redirect naar index pagina 
    flash("Cash added successfully!")
    return redirect("/")


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    
    if request.method == "GET":
        return render_template("buy.html")

    
    else:
        # symbol en aandelen opslaan
        symbol = request.form.get("symbol")
        shares = request.form.get("shares")
        quote = lookup(symbol)

        # return apology als symbol niet aan de eisen voldoet
        if quote == None:
            return apology("must provide valid stock symbol", 403)

        # return apology als aandelen niet zijn gespecificeerd
        if not shares:
            return apology("must provide number of shares", 403)

        # symbol in uppercase en aantal naar int zodat er geen incosistensies zijn
        symbol = symbol.upper()
        shares = int(shares)
        purchase = quote['price'] * shares

        # check of user genoeg cash heeft voor de transactie

        balance = db.execute("SELECT cash FROM users WHERE id = :id", id=session["user_id"])
        balance = balance[0]['cash']
        remainder = balance - purchase

        #error if cash balance groter dan transactie
        if remainder < 0:
            return apology("insufficient funds", 403)

        # query portfolio tabel for row met userid en stock symbool
        row = db.execute("SELECT * FROM portfolio WHERE userid = :id AND symbol = :symbol",
                         id=session["user_id"], symbol=symbol)

        # if row doesn't exist yet, create it and include the shares being bought
        if len(row) != 1:
            db.execute("INSERT INTO portfolio (userid, symbol, shares) VALUES (:id, :symbol, :shares)",
               id=session["user_id"], symbol=symbol, shares=shares)

        
        oldshares = db.execute("SELECT shares FROM portfolio WHERE userid = :id AND symbol = :symbol",
                               id=session["user_id"], symbol=symbol)
        oldshares = oldshares[0]["shares"]

        # add gekochte aandelen aan eerder gekochte aandelen
        newshares = oldshares + shares

        # update aandelen in portfolio 
        db.execute("UPDATE portfolio SET shares = :newshares WHERE userid = :id AND symbol = :symbol",
                   newshares=newshares, id=session["user_id"], symbol=symbol)

        # update cash in users 
        db.execute("UPDATE users SET cash = :remainder WHERE id = :id",
                   remainder=remainder, id=session["user_id"])

        # update history 
        db.execute("INSERT INTO history (userid, symbol, shares, method, price) VALUES (:userid, :symbol, :shares, 'Buy', :price)",
                   userid=session["user_id"], symbol=symbol, shares=shares, price=quote['price'])

    # redirect to index page
    return redirect("/")



@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    
    rows = db.execute("SELECT symbol, shares, method, price, timestamp FROM history WHERE userid = :userid ORDER BY timestamp DESC", userid=session["user_id"])
    # return history 
    return render_template("history.html", rows=rows)
    #TODO: doesn't display timestamp/ transacted RESOLVED: variables were inconsistently named

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    session.clear()
    if request.method == "POST":

        # check of username is ingevoerd
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # check of pw is ingevoerd
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # check username bestaat en password = correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # onthouden welke user is ineglogd
        session["user_id"] = rows[0]["id"]

        # Redirect naar homepage
        return redirect("/")

    
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""
    session.clear()
    # Redirect naar login form
    return redirect("/")



@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    
    if request.method == "GET":
        return render_template("quote.html")

    else:

        # lookup ticker symbool uit quote.html formulier
        symbol = lookup(request.form.get("symbol"))

        # als lookup = None, error
        if symbol == None:
            return apology("invalid stock symbol", 403)

        # Return template met stock quote
        return render_template("quoted.html", symbol=symbol)



@app.route("/register", methods=["GET", "POST"])
def register():
    # Forget any user_id
    session.clear()

    if request.method == "POST":

        # check username is ingediend
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # checken of password ingediend is
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # password match
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("passwords do not match", 403)

        # vanzelfsprekend
        username = request.form.get("username")
        hash = generate_password_hash(request.form.get("password"))

        # Query database om te zien of username al bestaat
        rows = db.execute("SELECT * FROM users WHERE username = :username",
                          username=username)
        if len(rows) != 0:
            return apology("username is already taken", 403)

        # username en hash inserten in db
        db.execute("INSERT INTO users (username, hash) VALUES (:username, :hash)",
                   username=username, hash=hash)

        # redirect login page
        return redirect("/")

    
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
        
    if request.method == "GET":

        # portfolio tabel checken voor de huidige assets
        portfolio = db.execute("SELECT symbol FROM portfolio WHERE userid = :id",
                               id=session["user_id"])

        
        return render_template("sell.html", portfolio=portfolio)

    # if POST method, sell stock
    else:
        # sla stock symbool op, aantal aandelen
        symbol = request.form.get("symbol")
        shares = request.form.get("shares")
        quote = lookup(symbol)
        rows = db.execute("SELECT * FROM portfolio WHERE userid = :id AND symbol = :symbol",
                          id=session["user_id"], symbol=symbol)

        #symbool invalid -> error
        if len(rows) != 1:
            return apology("must provide valid stock symbol", 403)

        # error als shares niet is ingevoerd of <= 0
        if not shares:
            return apology("must provide number of shares", 403)

        # huidige aandelen van het bedrijf
        oldshares = rows[0]['shares']

        # aandelen wijigen van form naar int
        shares = int(shares)

        # error als user meer aandelen probeert te verkopen dan in zijn/ haar bezit
        if shares > oldshares:
            return apology("shares sold can't exceed shares owned", 403)

        # huidige prijs van aandelen
        sold = quote['price'] * shares

        # voeg waarde van verkochte aandelen toe aan balance
        cash = db.execute("SELECT cash FROM users WHERE id = :id", id=session['user_id'])
        cash = cash[0]['cash']
        cash = cash + sold

        # update balance in db
        db.execute("UPDATE users SET cash = :cash WHERE id = :id",
                   cash=cash, id=session["user_id"])

      
        newshares = oldshares - shares

       
        if shares > 0:
            db.execute("UPDATE portfolio SET shares = :newshares WHERE userid = :id AND symbol = :symbol",
                       newshares=newshares, id=session["user_id"], symbol=symbol)

      
        else:
            db.execute("DELETE FROM portfolio WHERE symbol = :symbol AND userid = :id",
                       symbol=symbol, id=session["user_id"])

        # update history tabel
        db.execute("INSERT INTO history (userid, symbol, shares, method, price) VALUES (:userid, :symbol, :shares, 'Sell', :price)",
                   userid=session["user_id"], symbol=symbol, shares=shares, price=quote['price'])

        # redirect index.html
        return redirect("/")
